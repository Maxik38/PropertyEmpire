# Handoff: Property row "enchant" tiers — final variant 9a

## Overview
Replaces the emoji property icons in the Portfolio list with a minimal line-art building icon, and makes the whole property row level up visually with the property's star rating. Both the icon frame and the card (background, sheen, border, glow) grow richer from 0★ to 5★, so a maxed property reads as "enchanted" at a glance.

## About the Design Files
The bundled HTML file is a **design reference** (a self-contained prototype), not production code to copy directly. Recreate it in the game's actual codebase using its existing UI framework and asset pipeline.

**Which part to build:** build option **`9a`** only — the TOP section, titled "Zlato doprava rovnako hore aj dole", six rows showing 0★–5★. Everything below it in the file (turns 8, 7, 6, 5, 4) is earlier exploration — ignore it.

## Fidelity
High-fidelity. Every gradient/shadow value below is final and can be lifted verbatim.

## Structure of one property row

```
outer frame  →  padding: 1px (0★) / 1.5px (1★+), border-radius: 18px,
                background: <frame gradient>, box-shadow: <glow>
  inner card →  border-radius: 17px (0★) / 16.5px (1★+),
                background: <card background>, padding: 14px,
                display:flex; align-items:center; gap:14px;
                position:relative; overflow:hidden
    sheen    →  absolutely positioned overlay, inset:0, background: <sheen>
    icon     →  52×52, SAME frame treatment as the card:
                padding 1px/1.5px, border-radius 14px,
                background: <frame gradient>, box-shadow: <glow>
                inner: 100%×100%, border-radius 11px, background #1a1a20,
                centered 26×26 SVG
    text     →  name 16px bold; 5 stars at 12px, 3px gap, 6px margin-top
                (earned #d9b24c, unearned #2f2f38)
    right    →  income "+€504K/h" 13px bold #4ade80, nowrap, with
                "(€21.4M)" 11px #9a9aa2 inline;
                below, "Predať" pill: bg #3a1414, border 1px #7a2a2a,
                text #f28b8b, radius 20px, padding 5px 16px, 12px bold
```

Rows stack vertically with a 12px gap. The frame is a **padded wrapper**, not a CSS `border` — that is what makes gradient borders possible.

### Icon SVG
Thin line-art building matching the bottom-nav icon style. `viewBox="0 0 24 24"`, `fill="none"`, `stroke="#9a9aa2"`, `stroke-width="1.4"`, round caps and joins. The stroke color is constant across all tiers — only the frame around it changes.

```svg
<path d="M4 20V9.5L12 4l8 5.5V20"/>
<path d="M9 20v-5h6v5"/>
<path d="M8.5 11.5h2M13.5 11.5h2"/>
```

Use the game's own icon set if it has a building glyph; keep the 1.4px stroke weight and `#9a9aa2` color.

## Tier table (index = star count 0–5)

**Frame gradient** — used on BOTH the card frame and the icon frame; this is what ties them together. Note 4★ is a **horizontal** (90deg) gradient so the top-right corner gets exactly as much gold as the bottom-right; all other tiers are diagonal.
```
0  #26262d
1  linear-gradient(145deg,#4a4232,#2c2c34 62%)
2  linear-gradient(145deg,#7a5f36,#2a2a32 60%)
3  linear-gradient(145deg,#b08c42,#2e2a30 65%)
4  linear-gradient(90deg,#f0cf74,#c9a35c 40%,#8a6a2a 72%,#312c30 96%)
5  conic-gradient(from 210deg,#ffe9a8,#d9b24c 22%,#7fd8c0 45%,#c9a8f0 64%,#d9b24c 82%,#ffe9a8)
```

**Card background:**
```
0  linear-gradient(160deg,#1c1c22,#17171b)
1  linear-gradient(160deg,#1f1d1c,#18181c 70%)
2  linear-gradient(160deg,#241e16,#18171b 70%)
3  linear-gradient(150deg,#2a2115,#191820 75%)
4  linear-gradient(150deg,#2c2315,#1a1620 72%)
5  linear-gradient(150deg,#332715,#1d1626 70%)
```

**Sheen overlay** (absolute, inset:0, inside the card's `overflow:hidden`):
```
0  none
1  radial-gradient(120% 90% at 6% 0%, #d9b24c0d, transparent 58%)
2  radial-gradient(120% 90% at 6% 0%, #d9b24c1a, transparent 60%)
3  radial-gradient(120% 90% at 6% 0%, #d9b24c26, transparent 62%)
4  radial-gradient(120% 95% at 6% 0%, #e8c76630, transparent 65%)
5  radial-gradient(120% 95% at 4% 0%, #ffe9a833, transparent 62%),
   radial-gradient(90% 80% at 100% 110%, #c9a8f026, transparent 60%)
```

**Glow / box-shadow** (applied to both the card frame and the icon frame):
```
0  none
1  0 2px 10px #4a423218
2  0 3px 14px #7a5f3622
3  0 4px 18px #b08c4230
4  0 4px 20px #e8c76633
5  0 6px 30px #d9b24c44
```

**Frame padding & inner radius:** 0★ → `1px` padding, `17px` card inner radius. 1★ and above → `1.5px` padding, `16.5px` card inner radius. The icon's inner radius is `11px` at every tier.

## Behavior notes
- The tier is driven purely by the property's `starsEarned` value (0–5, from the quality system: 20 quality upgrades = 1 star). No new data needed.
- 0★ stays fully neutral — it's the baseline the player compares against. The first star's change is deliberately subtle (warm bronze tint) so the ramp has room to grow.
- 4★ must NOT close the gold all the way around the card; the gradient fades into dark before the right edge. Keeping it horizontal (90deg) is deliberate — a diagonal made the top-right corner noticeably more gold than the bottom-right.
- 5★ is the only tier with a multi-hue conic frame and a second (violet) light source. Reserve it for maxed properties so it stays special.
- Optional polish (not in the prototype): a slow rotating shimmer on the 5★ conic frame, e.g. a rotating gradient layer at `6s linear infinite`. Keep it subtle and pause it off-screen for battery.
- All tiers must stay legible on the app's `#0b0b0e` background; text colors do not change per tier.

## Files
- `Property Icon Tiers.dc.html` — open and look at the **top** section, rows labelled 9a (0★ through 5★, top to bottom).
